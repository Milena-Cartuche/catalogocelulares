/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.catalogocelular;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author NICOL
 */
public class Celular {
    
    public Celular (String Modelo, String Marca, String Almacenamiento, float Precio) {
        this.Modelo = Modelo;
        this.Marca = Marca;
        this.Almacenamiento = Almacenamiento;
        this.Precio = Precio;
    }
    
    String Modelo;
    String Marca;
    String Almacenamiento;
    float Precio;


    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getAlmacenamiento() {
        return Almacenamiento;
    }

    public void setCAlmacenamiento(String Almacenamiento) {
        this.Almacenamiento = Almacenamiento;
    }

    public float getPrecio() {
        return Precio;
    }
    public void setPrecio(float Precio) {
        this.Precio = Precio;
    }
    public void GuardarCelular(){
        Connection conexionDb = conexionDb.getConnection();
        
        //Ejecutar operaciones en la BD
        //Crear la sentencia SQL
        String sentenciaSql = "INSERT INTO celulares (Modelo, Marca, Almacenamiento, Precio) VALUES (null,?,?,?,?)";
        try {
            //Configurar los paramewtros de la sentencia SQL
            PreparedStatement parametro = conexionDb.prepareStatement(sentenciaSql);
            parametro.setString(1, this.getModelo());
            parametro.setString(2, this.getMarca());
            parametro.setString(3, this.getAlmacenamiento());
            parametro.setFloat(4, this.getPrecio());

            //Ejecutar la sentecia SQL
            parametro.execute();
            conexionDb.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    void EliminarCelular() {
        Connection conexionDb = conexionDb.getConnection();
        
        //Ejecutar operaciones en la BD
        //Crear la sentencia SQL
        String sentenciaSql = "DELETE FROM celulares WHERE Marca=?";
        try {
            //Configurar los paramewtros de la sentencia SQL
            PreparedStatement parametro = conexionDb.prepareStatement(sentenciaSql);
            parametro.setString(1, this.getMarca());

            //Ejecutar la sentecia SQL
            parametro.execute();
            conexionDb.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
}
